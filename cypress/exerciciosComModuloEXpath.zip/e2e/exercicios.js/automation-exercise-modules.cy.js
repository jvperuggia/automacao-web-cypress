/// <reference types="cypress" />

const cadastro = require('../../modules/cadastro/indexCadastro.js')
const login = require('../../modules/login/indexLogin.js')

describe('Automation Exercise', () => {
  // Cadastro
//   cy.get() -> elementos baseados em css eSelector
//   cy.contains() -> elementos baseados em texto

  it('Cadastrar um novo usuário com sucesso', () => {
    cy.visit('https://www.automationexercise.com')
    cy.get('a[href*=login]').click()

    /** Iniciar Cadastro */
    cadastro.iniciarCadastro()
    /** Preencher Cadastro */
    cadastro.preencherCadastro()
    /** Verificar Cadastro com sucesso */
    cadastro.verificarSeCadastroFoiEfetuadoComSucesso()
    })

  it('Fazer login de usuário com sucesso', () => {
    cy.visit('https://www.automationexercise.com')
    cy.get('a[href*=login]').click()

    /** Iniciar Cadastro */
    login.preencherLogin(`arrasca@teste.com`, `123456`)
    /** Verificar Login com sucesso */
    login.verificarSeLoginFoiEfetuadoComSucesso()
    })

  it('Fazer login de usuário com email ou senha incorretos', () => {
    cy.visit('https://www.automationexercise.com')
    cy.get('a[href*=login]').click()

    /** Iniciar Cadastro */
    login.preencherLogin(`email_nao_cadastrado@teste.com`, `123456`)
    /** Verificar Login com sucesso */
    login.verificarSeLoginFalhou()
    })

  it('Fazer logout', () => {
    cy.visit('https://www.automationexercise.com')
    cy.get('a[href*=login]').click()

    /** Iniciar Cadastro */
    login.preencherLogin(`arrasca@teste.com`, `123456`)
    /** Verificar Login com sucesso */
    login.verificarSeLoginFoiEfetuadoComSucesso()
    /** Efetuar Logout */
    login.efetuarLogout()
    /** Verificar Logout com sucesso */
    login.verificarSeUsuarioFoiDeslogadoComSucesso()
    })

  it('Tentar cadastrar um usuário com email já existente', () => {
    cy.visit('https://www.automationexercise.com')
    cy.get('a[href*=login]').click()

    /** Iniciar Cadastro */
    cadastro.iniciarCadastroEmailExistente()
    /** Verificar Cadastro com sucesso */
    cadastro.verificarMensagemDeCadastroExistente()
    })  
 
})